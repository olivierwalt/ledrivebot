#!/bin/bash
python bot_code128.py